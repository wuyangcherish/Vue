<template>
	<div class="scroll-container" slot="body">
		<div class="content-container">
			内容1
		</div>
		<div class="content-container">
			内容222
		</div>
		<div class="content-container">
			内容333
		</div>
	</div>
</template>